<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User as ModelsUser;
use Exception;
use Illuminate\Support\Facades\Validator;

class UserLoginController extends Controller
{
    public function login(Request $request)
    {
        $validator = Validator::make($request->all() , [
            'phone'     => 'required|min:10|max:10',
        ]);

        if($validator->fails())
        {
            return response()->json(['status' => false , 'msg' => $validator->errors()->first()]);
            exit;
        }
        else
        {
            $checkPhoneExists = ModelsUser::where(['phone' => $request->phone])->first();
            $otp                            = 1234;
            if($checkPhoneExists)
            {
                $checkPhoneExists->otp_verify   = $otp;
                $result                         = $checkPhoneExists->update();

                if ($result) {
                    try {
                        $msg = "Your one time password :" . $otp;
                        $recipient = "+91" .$request->phone;
                        $this->sendMessage($msg, $recipient);
                    } catch (Exception $e) {

                    }
                }

                if($result)
                {
                    return response()->json(['status' => true , 'msg' => 'Otp send your phone number', 'data'=> $checkPhoneExists]);
                    exit;
                }
                else
                {
                    return response()->json(['status' => false , 'msg' => 'Something went wrong Try again later!!']);
                    exit;
                }
            }
            else
            {
                $data = new ModelsUser();
                $input['phone']     = $request->phone;
                $input['otp_verify']= $otp;
                $result = $data->fill($input)->save();

                if($result) {
                    try {
                        $msg = "Your one time password :" . $otp;
                        $recipient = "+91" .$request->phone;
                        $this->sendMessage($msg, $recipient);
                    } catch (Exception $e) {

                    }
                }

                if($result)
                {
                    $user = ModelsUser::where('id', $data->id)->first();
                    return response()->json(['status' => true , 'msg' => 'Otp send your phone number', 'data'=> $user]);
                    exit;
                }
                else
                {
                    return response()->json(['status' => false , 'msg' => 'Something went wrong Try again later!!']);
                    exit;
                }
            }
        }


    }

    public function otp_verify(Request $request)
    {

        $rules = [
            'otp' => 'required|min:4|max:4',
            'user_id' => 'required|numeric'
        ];
        $msg = [
            'otp.required' => 'Otp required',
            'user_id.required' => 'User ID required',
        ];

        $validator = Validator::make($request->all() , $rules , $msg);
        if($validator->fails())
        {
            return response()->json(['status' => false , 'msg' => $validator->errors()->first()]);
            exit();
        }
        else
        {
            $getPhone = ModelsUser::where('id', $request->user_id)->first();
            if(empty($getPhone)){
                return response()->json(['status' => false , 'msg' => 'User ID is invalid!!']);
                exit();
            }

            $otpVerify = $request->otp;

            if($getPhone->otp_verify == $otpVerify)
            {
                return response()->json(['status' => true, 'msg' => "Success, Welcome Back!", 'data' => $getPhone]);
                exit;
            }
            else
            {
                return response()->json(['status' => false, 'msg' => "OTP do not match !!!"]);
                exit;
            }


        }
    }


}
